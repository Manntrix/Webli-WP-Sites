<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'ips' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '?{#zx$2+ A/Qu*ppJf 6E(^s$.CrT$2>1iD6W!?U@B4F9cF9#A7%,OlA7qHleRmS' );
define( 'SECURE_AUTH_KEY',   'cD3/v{>I9)MbBp|Br TZ5^NBQ3q)T_>IhtSUH-w^WK G!mdDG90sQ=zFrgQ4gIgq' );
define( 'LOGGED_IN_KEY',     'o0THzx`YmS{}k=(d!yB(y+/z}8jy%m&chp[~youfSPQ[fEkT#Ctxxj5>CHUP{A_$' );
define( 'NONCE_KEY',         'm)A8xf^q<qa_#soX=tO74;iTJx|?~3}Xa]3s V@.U>?;$X^>K/1U#sV+Gh-[xro-' );
define( 'AUTH_SALT',         'efD1&!fttj:FI`.7WGE~nNlyp2L[v_uH}[pJkQ#gY{C40K8Me7lqnMKO,h[V|gf|' );
define( 'SECURE_AUTH_SALT',  '-W[$EF+b*DY<} yXW)Yu_ug+4!dBPLX5v{;qvdLAT=WM-t_/r8QGV3_u-waez,[c' );
define( 'LOGGED_IN_SALT',    'MFy(n[W)JF7*pbod@I{v{=);oTZ3dQ/mq2<CoCg|zx`8mZmV0wzn !57O98@):<]' );
define( 'NONCE_SALT',        'T42v|Q!o|1|WZwj>/aw7gQ#Cja!c n5uWM<+EPn?^Lm|*3T%h(vD*w;k2X?-uV:5' );
define( 'WP_CACHE_KEY_SALT', 'D.8u2zo-ghd?>L2a.=vGrzQ016F!upcrwlGk*uXs5m5*@>&UE~)C*eJq40T!;&$5' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
