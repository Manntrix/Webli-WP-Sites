<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'webli' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '8#=x452ZWUcX,$I&Mc{oTbrqF4=UFHpP:3#%T[5I@)p&G!YYq~7E{+x<42>`.!B0' );
define( 'SECURE_AUTH_KEY',   'j,lk>$!7U.1^+xFMrY~N>!qJ+}@~0F#a9$s%s[eKf7oUTp{cRgfdzexSM!__|qpq' );
define( 'LOGGED_IN_KEY',     '&g`Wg7]]^HO!A!bKNkxI77>rF.Z~,@DT 8]oz<4b Ht)+>cp4]Qra[XD~&:2rH0~' );
define( 'NONCE_KEY',         's[ yO=d~fB)UzmQ<9w0[b6:epT(]:W)X4tk:k(b9xpM>|p9f((:=.f-r94]3v!{j' );
define( 'AUTH_SALT',         'B;N[tS`c7!!Z?f>R!C={;J7Vn{w6J![>.+.Z`]]gTT^9NK6;%j;*(7BG>Y`.XYb>' );
define( 'SECURE_AUTH_SALT',  'hb@}l9ZU$Wp:}e:xy+MvTdEa$hP;ytDp8@GFDzj<~qVTDNTZ,]>7E3QHh=1t6`lN' );
define( 'LOGGED_IN_SALT',    'HnKBnhC9+L)b2(DwMP;+ypaR_Ur%tjt<q4AZFO;rW)pA|v3lQ#r42VXq0h13uE*!' );
define( 'NONCE_SALT',        '%W#i_/%kec!5XC|+|aO}/1~N[v9R}+Rqpo<wEIwqtb;s:tnGQro.:WNF`EA;#{<2' );
define( 'WP_CACHE_KEY_SALT', 'x9(VD??Zg8UouKE&22&R=7XvydI jb k5K*oJLjvslDaOJ~zb~+WU[.,Lvy2#-&b' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
