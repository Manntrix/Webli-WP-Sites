<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'webli' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '{qF+,I6q,8o-oo+W**Gr~TZ__kES5DemNm^12|;F=W{2UQ>qM$[a+FLTn,]wwJY<' );
define( 'SECURE_AUTH_KEY',   '+CDzA)<w H45hU(9w+D <U.X1^<9ZB<DUEIR5@#{dUJ$#Q/HBOfcx(L]&HsCs{(2' );
define( 'LOGGED_IN_KEY',     'e]F+B-<D3$aXD&X9-u[m`Tl/tG_j$=,Vh ,E~F 7X5zaH:+Q}fz~-n56.scFPak}' );
define( 'NONCE_KEY',         'cIc@ztwGwq{N|PO>]tZB6[<hthfU7a{bi8-;U*cH,L[W!B*y?]|..]apennW$l&;' );
define( 'AUTH_SALT',         '-r10W3^`p<~Z;FC%<g8 Ql/%$oytH`wCkfNk[e^;mG6^Od+ql/rEkSdah}/7HwC#' );
define( 'SECURE_AUTH_SALT',  'fZ$0V8l*GmhPggU*TwPXc{X !fkC5KmIO3-A~@Ga-4p%%~*w?^[|VCqC/rw,8^{N' );
define( 'LOGGED_IN_SALT',    'S%YwaCG(Cso87Oy-|l__*,ex&r1r{o$-gs7o(Sa;(7Xos$WH!]e[Jto6w9ykb13l' );
define( 'NONCE_SALT',        'cn^mdw0zg3C_`_Aw,%@^z+};3N{5Kn?T$|W7W,2o#j0J[;8,$W2Y(KXEE;C:+$Vz' );
define( 'WP_CACHE_KEY_SALT', 'QW8gioMgZ.th(yKELm~X%{dOLera2.OW`5wQ1%-z9j?KLm#$iK<c6Ua@>qIc+1tt' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
