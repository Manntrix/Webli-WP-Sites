<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'webli' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'aW-UFa1lNATXYhM.^OhjgRRnP3@% Hg~X!e_4?Y$#`wD.Gj*VmEUSh_6R%4NJIKn' );
define( 'SECURE_AUTH_KEY',   '*-Z7cJzVXah5ndyH4Y~1|,8y&`R:!%7d;L>EGvmA0GM,|^dIwsJ($0u?9,%Z$3+/' );
define( 'LOGGED_IN_KEY',     'nqHbdmt:}#HL~J]WgKke0{Pm|h> ^[U]pnzLY=o:79~3Q1dRD,CVD;t1:PoZO)X{' );
define( 'NONCE_KEY',         '8s[2 $^9WwV6_1Q$-6L!:d2_wf`aT@kL#L64HyR_5t*g;i{6-h!=}JvO]+7 Gk[;' );
define( 'AUTH_SALT',         'Uf[LT[CF<;4=WZ&JX- j!lLLH[Jvyda_b)K+S-s9; v)-9p$?=,rA1!.[;Jvh:Z_' );
define( 'SECURE_AUTH_SALT',  '%OTy=AnKY=.^6l)Xy6_,d/yQ%dx7%3 #l4$ADP>2QJxm`8>=|3Z$3PQE!c?hnSMf' );
define( 'LOGGED_IN_SALT',    'mU9o}UO<jh-NJEqE-Pi~W]a;D@ } XH*`4m$A`#Fv?d?Fsfv>%<7eA0<^RbL@3n=' );
define( 'NONCE_SALT',        '6|%O9I3=SQ9u}/g Krw.64D!b8wH5LAiBAsBZ6leXk8o+#vJc%un%(u;Y7{{u~V_' );
define( 'WP_CACHE_KEY_SALT', ')+RU{ ~u}QlnR]2[68dPzN?)>cecPE@=Pk%ySRl/e3`BIKl)[jkc#~Snc(!H/>^<' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
